import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "engine"))

from engine import create_engine


def load_puzzles():
    data = json.loads((ROOT / "data" / "puzzles.json").read_text(encoding="utf-8"))
    return data["puzzles"]


def test_correct_answers():
    puzzles = load_puzzles()
    game = create_engine(puzzles)

    answers = [
        ("fiz", "—"),
        ("tiv", "e"),
        ("vi", "m"),
        ("fu", "i"),
    ]

    for root, ending in answers:
        result = game["check"](root, ending)
        assert result["correct"] is True
        game["next"]()

    assert game["get_score"]() == 4


if __name__ == "__main__":
    test_correct_answers()
    print("ok: 4/4")
