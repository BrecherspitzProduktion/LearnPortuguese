# Verb Dock

Lernspiel-Kern für portugiesische Verbformen.

Die **Regeln** liegen in der Engine.  
Das **Frontend** (Tetris, Lego, Scrabble, Quiz) kommt später und darf nur die Engine-API nutzen.

## Struktur

```
verb-dock/
  data/puzzles.json      # Inhalt, austauschbar
  engine/engine.js       # Regel-Kern (Browser / Node)
  engine/engine.py       # gleicher Kern in Python
  tests/test_engine.py
  README.md
```

## Engine-API

- `getPuzzle()` / `get_puzzle()` — aktuelles Rätsel
- `check(root, ending)` — richtig oder falsch
- `next()` — nächstes Rätsel
- `getScore()` / `get_score()` — Punktestand

Leere Endung wird als `—` angezeigt (`fiz` + nichts).

## Beispiele in `data/puzzles.json`

1. `fazer` → **fiz**
2. `ter` → **tive**
3. `vir` → **vim**
4. `ser / ir` → **fui**

## Test

```bash
python tests/test_engine.py
```

## Nächste Schritte

1. Repo auf GitHub anlegen und diesen Ordner pushen
2. Ein Text-Frontend (Buttons)
3. Später Godot-Frontend an dieselbe JSON-Datei hängen
