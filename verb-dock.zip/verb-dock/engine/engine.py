import random


def create_engine(puzzles):
    if not puzzles:
        raise ValueError("Engine needs at least one puzzle.")

    state = {"index": 0, "score": 0}

    def current():
        return puzzles[state["index"]]

    def get_puzzle():
        p = current()
        empty_ending = "—" if p["ending"] == "" else p["ending"]
        roots = [p["root"], *p["wrong_roots"]]
        endings = [empty_ending, *p["wrong_endings"]]
        random.shuffle(roots)
        random.shuffle(endings)
        return {
            "id": p["id"],
            "verb": p["verb"],
            "infinitive": p["infinitive"],
            "tense": p["tense"],
            "person": p["person"],
            "sentence": p["sentence"],
            "roots": roots,
            "endings": endings,
        }

    def check(root, ending):
        p = current()
        chosen_ending = "" if ending == "—" else ending
        ok = root == p["root"] and chosen_ending == p["ending"]
        if ok:
            state["score"] += 1
        return {
            "correct": ok,
            "form": p["form"],
            "sentence": p["sentence"].replace("___", p["form"]),
        }

    def next_puzzle():
        state["index"] = (state["index"] + 1) % len(puzzles)
        return get_puzzle()

    return {
        "get_puzzle": get_puzzle,
        "check": check,
        "next": next_puzzle,
        "get_score": lambda: state["score"],
    }
