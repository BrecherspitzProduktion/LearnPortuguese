function shuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

export function createEngine(puzzles) {
  if (!Array.isArray(puzzles) || puzzles.length === 0) {
    throw new Error("Engine needs at least one puzzle.");
  }

  let index = 0;
  let score = 0;

  function current() {
    return puzzles[index];
  }

  function getPuzzle() {
    const p = current();
    const emptyEnding = p.ending === "" ? "—" : p.ending;

    return {
      id: p.id,
      verb: p.verb,
      infinitive: p.infinitive,
      tense: p.tense,
      person: p.person,
      sentence: p.sentence,
      roots: shuffle([p.root, ...p.wrong_roots]),
      endings: shuffle([emptyEnding, ...p.wrong_endings])
    };
  }

  function check(root, ending) {
    const p = current();
    const chosenEnding = ending === "—" ? "" : ending;
    const ok = root === p.root && chosenEnding === p.ending;

    if (ok) score += 1;

    return {
      correct: ok,
      form: p.form,
      sentence: p.sentence.replace("___", p.form)
    };
  }

  function next() {
    index = (index + 1) % puzzles.length;
    return getPuzzle();
  }

  return {
    getPuzzle,
    check,
    next,
    getScore: () => score,
    getIndex: () => index
  };
}
