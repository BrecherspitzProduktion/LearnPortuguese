#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-verb-dock}"

mkdir -p "$ROOT/data" "$ROOT/engine" "$ROOT/tests" "$ROOT/scripts"

cat > "$ROOT/.gitignore" << 'EOF'
.DS_Store
node_modules/
__pycache__/
*.pyc
.godot/
*.import
.vscode/
.idea/
EOF

cat > "$ROOT/data/puzzles.json" << 'EOF'
{
  "version": 1,
  "language": "pt",
  "level": "1-preterito-perfeito",
  "puzzles": [
    {
      "id": "fazer_pp_eu",
      "verb": "fazer",
      "infinitive": "fazer",
      "tense": "preterito_perfeito",
      "person": "eu",
      "root": "fiz",
      "ending": "",
      "form": "fiz",
      "sentence": "Ontem eu ___ o trabalho.",
      "wrong_roots": ["faz", "feit"],
      "wrong_endings": ["o", "ei", "aste"]
    },
    {
      "id": "ter_pp_eu",
      "verb": "ter",
      "infinitive": "ter",
      "tense": "preterito_perfeito",
      "person": "eu",
      "root": "tiv",
      "ending": "e",
      "form": "tive",
      "sentence": "Eu ___ sorte na alfândega.",
      "wrong_roots": ["tenh", "ter"],
      "wrong_endings": ["o", "este", "emos"]
    },
    {
      "id": "vir_pp_eu",
      "verb": "vir",
      "infinitive": "vir",
      "tense": "preterito_perfeito",
      "person": "eu",
      "root": "vi",
      "ending": "m",
      "form": "vim",
      "sentence": "Eu ___ do deserto.",
      "wrong_roots": ["venh", "vir"],
      "wrong_endings": ["o", "este", "eio"]
    },
    {
      "id": "ser_ir_pp_eu",
      "verb": "ser",
      "infinitive": "ser / ir",
      "tense": "preterito_perfeito",
      "person": "eu",
      "root": "fu",
      "ending": "i",
      "form": "fui",
      "sentence": "Eu ___ a Lisboa.",
      "wrong_roots": ["so", "va"],
      "wrong_endings": ["o", "iste", "imos"]
    }
  ]
}
EOF

cat > "$ROOT/engine/engine.js" << 'EOF'
function shuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

export function createEngine(puzzles) {
  if (!Array.isArray(puzzles) || puzzles.length === 0) {
    throw new Error("Engine needs at least one puzzle.");
  }

  let index = 0;
  let score = 0;

  function current() {
    return puzzles[index];
  }

  function getPuzzle() {
    const p = current();
    const emptyEnding = p.ending === "" ? "—" : p.ending;

    return {
      id: p.id,
      verb: p.verb,
      infinitive: p.infinitive,
      tense: p.tense,
      person: p.person,
      sentence: p.sentence,
      roots: shuffle([p.root, ...p.wrong_roots]),
      endings: shuffle([emptyEnding, ...p.wrong_endings])
    };
  }

  function check(root, ending) {
    const p = current();
    const chosenEnding = ending === "—" ? "" : ending;
    const ok = root === p.root && chosenEnding === p.ending;

    if (ok) score += 1;

    return {
      correct: ok,
      form: p.form,
      sentence: p.sentence.replace("___", p.form)
    };
  }

  function next() {
    index = (index + 1) % puzzles.length;
    return getPuzzle();
  }

  return {
    getPuzzle,
    check,
    next,
    getScore: () => score,
    getIndex: () => index
  };
}
EOF

cat > "$ROOT/engine/engine.py" << 'EOF'
import random


def create_engine(puzzles):
    if not puzzles:
        raise ValueError("Engine needs at least one puzzle.")

    state = {"index": 0, "score": 0}

    def current():
        return puzzles[state["index"]]

    def get_puzzle():
        p = current()
        empty_ending = "—" if p["ending"] == "" else p["ending"]
        roots = [p["root"], *p["wrong_roots"]]
        endings = [empty_ending, *p["wrong_endings"]]
        random.shuffle(roots)
        random.shuffle(endings)
        return {
            "id": p["id"],
            "verb": p["verb"],
            "infinitive": p["infinitive"],
            "tense": p["tense"],
            "person": p["person"],
            "sentence": p["sentence"],
            "roots": roots,
            "endings": endings,
        }

    def check(root, ending):
        p = current()
        chosen_ending = "" if ending == "—" else ending
        ok = root == p["root"] and chosen_ending == p["ending"]
        if ok:
            state["score"] += 1
        return {
            "correct": ok,
            "form": p["form"],
            "sentence": p["sentence"].replace("___", p["form"]),
        }

    def next_puzzle():
        state["index"] = (state["index"] + 1) % len(puzzles)
        return get_puzzle()

    return {
        "get_puzzle": get_puzzle,
        "check": check,
        "next": next_puzzle,
        "get_score": lambda: state["score"],
    }
EOF

cat > "$ROOT/tests/test_engine.py" << 'EOF'
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "engine"))

from engine import create_engine


def load_puzzles():
    data = json.loads((ROOT / "data" / "puzzles.json").read_text(encoding="utf-8"))
    return data["puzzles"]


def test_correct_answers():
    puzzles = load_puzzles()
    game = create_engine(puzzles)

    answers = [
        ("fiz", "—"),
        ("tiv", "e"),
        ("vi", "m"),
        ("fu", "i"),
    ]

    for root, ending in answers:
        result = game["check"](root, ending)
        assert result["correct"] is True
        game["next"]()

    assert game["get_score"]() == 4


if __name__ == "__main__":
    test_correct_answers()
    print("ok: 4/4")
EOF

cat > "$ROOT/README.md" << 'EOF'
# Verb Dock

Lernspiel-Kern für portugiesische Verbformen.

Die Regeln liegen in der Engine.
Das Frontend (Tetris, Lego, Scrabble, Quiz) kommt später.

## Struktur

```
verb-dock/
  data/puzzles.json
  engine/engine.js
  engine/engine.py
  tests/test_engine.py
  scripts/create_repo.sh
  README.md
```

## Engine-API

- getPuzzle() / get_puzzle()
- check(root, ending)
- next()
- getScore() / get_score()

## Test

```bash
python tests/test_engine.py
```

## GitHub

```bash
bash scripts/create_repo.sh verb-dock
cd verb-dock
git init
git add .
git commit -m "Initial engine and 4 pretérito-perfeito puzzles"
```
EOF

chmod +x "$ROOT/scripts/create_repo.sh" 2>/dev/null || true

echo "Created $ROOT"
echo "Next:"
echo "  cd $ROOT"
echo "  git init && git add . && git commit -m \"Initial engine and 4 puzzles\""
echo "  python tests/test_engine.py"
